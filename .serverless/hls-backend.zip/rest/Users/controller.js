const connectToDatabase = require("../../db");
const uuid = require("uuid");
const { HTTPError } = require("../httpResp");
const { QueryTypes } = require('sequelize');

module.exports.create = async(event) => {
    try {
        const input = typeof event.body === "string" ? JSON.parse(event.body) : event.body;
        const { Users } = await connectToDatabase();
        const dataObject = Object.assign(
            input,
            { id: uuid.v4() },
        );

        const userObject = await Users.findOne({
            where: {
                email: dataObject.email,
            },
        });
        if (userObject)
            throw new HTTPError(
                400,
                `User with email id: ${dataObject.email} already exist`
            );
        const userModel = await Users.create(dataObject);

        return {
            statusCode: 200,
            headers: {
                "Content-Type": "text/plain",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
            },
            body: JSON.stringify(userModel),
        }
    } catch (error) {
        return {
            statusCode: error.statusCode || 500,
            headers: {
                "Content-Type": "text/plain",
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": true,
            },
            body: JSON.stringify({
                error: error.message || "Could not create the user.",
            }),
        };
    }
}